﻿using TransferMail.Domain.Model;
using TransferMail.Domain.Interfaces;
using TransferMail.Domain.Enum;

using System;
using System.Configuration;
namespace TransferMail.Services
{
    public class MailTransferService : ITransferMail
    {
        private readonly IMailContainerData _ContainerDataStore;


        public MailTransferService(IMailContainerData ContainerDatastore)
        {

            _ContainerDataStore = ContainerDatastore;
        }

        #region :: Get Containers and Initiate Transfer
        public MakeMailTransferResult MakeMailTransfer(MakeMailTransferRequest request)
        {
            MakeMailTransferResult result = null;
            try
            {
                MailTransferContainerDetails MailTranserContainerDetails = _ContainerDataStore.GetMailTransferDetails(request);
                TransferItems(MailTranserContainerDetails, request, out result);
            }
            catch (Exception)
            {
                // Logging
            }
            return result;
        }
        #endregion

        #region :: Transfer Mail Items

        /*
        * Reduce the container capacity on the source container and increase the destination container capacity 
        * by the same amount.Call the UpdateMailContainer method to update source an destination mail containers
        */
        public void TransferItems(MailTransferContainerDetails mailTranserContainerDetails, MakeMailTransferRequest request, out MakeMailTransferResult result)
        {
            result = null;
            try
            {
                result = IsRequestValid(mailTranserContainerDetails, request);
                if (result.Success)
                {
                    mailTranserContainerDetails.SourceMailContainer.Capacity -= request.NumberOfMailItems;
                    mailTranserContainerDetails.DestinationMailContainer.Capacity += request.NumberOfMailItems;
                    _ContainerDataStore.UpdateMailContainer(mailTranserContainerDetails);

                }
            }
            catch (Exception)
            {
                // Logging
                result.Success = false;
            }

        }
        #endregion

        #region :: Check the Containers & Request is valid or Not
        /*
         * Check both request and destination mail container is not null.
         * check if the destination mail container has allowed mail type as requested
         * Check if the capacity of destination mail container is more or equal to no. of Items  from source(just a validation although it has been said that it has unlimited capacity)
         * Check if the source & destination container are operational
         */
        public MakeMailTransferResult IsRequestValid(MailTransferContainerDetails ContainerDetails, MakeMailTransferRequest request)
        {
            bool result = false;
            try
            {
                result = ContainerDetails.SourceMailContainer != null && ContainerDetails.DestinationMailContainer != null;
                result &= (ContainerDetails.SourceMailContainer.Status == Status.Operational && ContainerDetails.DestinationMailContainer.Status == Status.Operational);
                result &= ContainerDetails.DestinationMailContainer.AllowedMailType.HasFlag(request.MailType);
                result &= ContainerDetails.DestinationMailContainer.Capacity >= request.NumberOfMailItems;

            }
            catch (Exception)
            {
                // Logging
                result = false;
            }
            return new MakeMailTransferResult()
            {
                Success = result
            };
        }
        #endregion
    }
}
