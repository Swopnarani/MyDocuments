﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransferMail.Domain.Interfaces;
using TransferMail.Domain.Model;

namespace Datastore
{
    public class BackupMailContainerDataStore : IMailContainerData
    {
        public MailContainer GetMailContainer(string mailContainerNumber)
        {
            // Access the database and return the retrieved mail container. Implementation not required for this exercise.
            return new MailContainer();
        }

        public void UpdateMailContainer(MailContainer mailContainer)
        {
            // Update mail container in the database. Implementation not required for this exercise.
        }

        public MailTransferContainerDetails GetMailTransferDetails(MakeMailTransferRequest Request)
        {
            // Provides both source and destination container details
            return new MailTransferContainerDetails();
        }

        public void UpdateMailContainer(MailTransferContainerDetails MailTransferContainers)
        {
            // Update mail container in the database. Implementation not required for this exercise.
        }


    }
}
