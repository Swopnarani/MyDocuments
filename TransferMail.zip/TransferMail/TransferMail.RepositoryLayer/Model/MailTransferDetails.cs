﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TransferMail.Domain.Model
{
    public class MailTransferContainerDetails
    {
        public MailContainer SourceMailContainer;
        public MailContainer DestinationMailContainer;
        //  need to add data store 
    }
}
