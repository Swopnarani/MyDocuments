﻿namespace TransferMail.Domain.Model
{
    public class MakeMailTransferResult
    {
        public bool Success { get; set; }
    }
}
