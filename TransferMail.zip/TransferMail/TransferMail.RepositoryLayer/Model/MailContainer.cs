﻿using System;
using System.Collections.Generic;
using System.Text;
using TransferMail.Domain.Enum;

namespace TransferMail.Domain.Model
{
    public class MailContainer
    {
        public string MailContainerNumber { get; set; }
        public int Capacity { get; set; }
        public Status Status { get; set; }
        public AllowedMailType AllowedMailType { get; set; }
    }
}
