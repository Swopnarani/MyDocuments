﻿namespace TransferMail.Domain.Enum
{
    
        public enum MailType
        {
        StandardLetter,
        LargeLetter,
        SmallParcel
    }
}
