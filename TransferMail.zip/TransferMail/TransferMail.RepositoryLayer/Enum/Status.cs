﻿namespace TransferMail.Domain.Enum
{
    public enum Status
    {
        Operational,
        OutOfService,
        NoTransfersIn
    }

}
