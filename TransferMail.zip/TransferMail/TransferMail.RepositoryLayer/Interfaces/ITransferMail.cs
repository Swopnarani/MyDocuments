﻿using System;
using System.Collections.Generic;
using System.Linq;
using TransferMail.Domain.Model;

namespace TransferMail.Domain.Interfaces
{
    public interface ITransferMail
    {
        MakeMailTransferResult MakeMailTransfer(MakeMailTransferRequest request);
    }
}
