﻿using System;
using System.Collections.Generic;
using System.Text;
using TransferMail.Domain.Model;

namespace TransferMail.Domain.Interfaces
{
    public interface IMailContainerData
    {
         MailContainer GetMailContainer(string mailContainerNumber);
         void UpdateMailContainer(MailContainer mailContainer);
         MailTransferContainerDetails GetMailTransferDetails(MakeMailTransferRequest Request);
         void UpdateMailContainer(MailTransferContainerDetails MailTransferContainers);
    }
}
